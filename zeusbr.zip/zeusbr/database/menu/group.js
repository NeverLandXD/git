const group = (pushname, prefix, botName, ownerName) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/556993899391
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


                     𝚉𝙴𝚄𝚂

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}opengc*
║➩ ❍ *${prefix}closegc*
║➩ ❍ *${prefix}promote*
║➩ ❍ *${prefix}demote*
║➩ ❍ *${prefix}tagall*
║➩ ❍ *${prefix}tagall2*
║➩ ❍ *${prefix}tagall3*
║➩ ❍ *${prefix}tagall4*
║➩ ❍ *${prefix}tagall5*
║➩ ❍ *${prefix}add*
║➩ ❍ *${prefix}kick*
║➩ ❍ *${prefix}listadmins*
║➩ ❍ *${prefix}linkgroup*
║➩ ❍ *${prefix}leave*
║➩ ❍ *${prefix}welcome*
║➩ ❍ *${prefix}nsfw*
║➩ ❍ *${prefix}delete*
║➩ ❍ *${prefix}simih*
║➩ ❍ *${prefix}ownergroup*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.group = group
